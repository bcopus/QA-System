package copus.qa

import copus.corenlp.{AbstractDocument, CoreNlpWrapper, Document}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.feature.{HashingTF, IDF}
import org.apache.spark.rdd.RDD

object TfIdfDocumentProcessor {

  def processElements(rDD: RDD[AbstractDocument]): Seq[AbstractDocument] = {
    //process each document into a sequence of lemmatized tokens
    val elementSequences = rDD.map(doc => {
      doc.getTokens.map(tok => {
        tok.getLemma
      }).toSeq
    })
    elementSequences.foreach(doc => println(doc))

    //calculate TF-IDF data
    val hashingTF = new HashingTF()
    val termFrequencies = hashingTF.transform(elementSequences)
    termFrequencies.cache()

    val idf = new IDF().fit(termFrequencies) //returns IDFModel
    val tfIdf = idf.transform(termFrequencies) //returns TF-IDF SparseVectors

    //collect elements and TF-IDF data and save the vectors in each element
    val dd = rDD.collect()
    val tt = tfIdf.collect()

    for (i : Int <- 0 until rDD.count().toInt) {
      dd.apply(i).setTfIdfVector(tt.apply(i).toSparse)
    }
    return dd
  }//processElements()

  def main(args: Array[String]): Unit = {
    System.setProperty("hadoop.home.dir", "C:\\winutils")
    val sparkConf = new SparkConf().setAppName("QASystemLab3").setMaster("local[*]")
    val sc = new SparkContext(sparkConf)

    val files = sc.wholeTextFiles("corpus")

    //Process the corpus documents with full annotation;
    //Save the TF-IDF data per-document and per-sentence;
    //Save documents and sentences in object files for subsequent use.
    //First: The documents
    val documents = files.map(file => CoreNlpWrapper.prepareText(file._2)).toArray()
    val docsRDD : RDD[AbstractDocument] = sc.parallelize(documents)

    //calculate TF-IDF for documents and save the vector in each document
    val dd = processElements(docsRDD)
    //serialize and write the documents as an object file
    sc.parallelize(dd).saveAsObjectFile("preparedCorpus\\documents.obj")

    //Second: the sentences
    val sentences = documents.flatMap(doc => doc.getSentences)
    val sentencesRDD : RDD[AbstractDocument] = sc.parallelize(sentences)

    val ss = processElements(sentencesRDD)
    sc.parallelize(ss).saveAsObjectFile("preparedCorpus\\sentences.obj")

  }//main()

}//object TfIdfDocumentProcessor

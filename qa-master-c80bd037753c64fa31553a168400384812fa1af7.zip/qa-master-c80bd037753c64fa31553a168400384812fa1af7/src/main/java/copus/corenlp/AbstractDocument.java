package copus.corenlp;

import org.apache.spark.mllib.linalg.SparseVector;

import java.io.Serializable;
import java.util.Arrays;

public abstract class AbstractDocument implements Serializable {
  protected Token[] tokens;
  protected SparseVector tfIdfVector;
  
  public Token[] getTokens() {
    return tokens;
  }
  
  public SparseVector getTfIdfVector() {
    return tfIdfVector;
  }
  
  public void setTfIdfVector(SparseVector tfIdfVector) {
    this.tfIdfVector = tfIdfVector;
  }
  
  public double score(Question question) {
    double score = 0.0;
    int[] indices = this.getTfIdfVector().indices();
    double[] values = this.getTfIdfVector().values();
    
    for(int hash : question.getTargetTermHashes()) {
      int index = Arrays.binarySearch(indices, hash);
      if(index >= 0)
        score += values[index];
    }
    return score;
  }//score()
}//class AbstractDocument

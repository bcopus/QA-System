package copus.corenlp;

public interface AnswerProvider {
  Answer extractAnswer(Question question);
}

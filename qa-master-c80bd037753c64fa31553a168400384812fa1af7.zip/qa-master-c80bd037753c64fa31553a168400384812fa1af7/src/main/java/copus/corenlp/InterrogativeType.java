package copus.corenlp;

public enum InterrogativeType {
  WHO, WHAT, WHEN, WHERE, WHY, UNKNOWN
}

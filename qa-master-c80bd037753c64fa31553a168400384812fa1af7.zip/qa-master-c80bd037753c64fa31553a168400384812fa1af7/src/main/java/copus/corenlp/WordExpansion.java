package copus.corenlp;

import java.util.ArrayList;
import java.util.HashMap;

public class WordExpansion {
  private static HashMap<String, String[]> wordExpansions = null;

  public WordExpansion(String... associates) {
    for(String associate : associates) {
      ArrayList<String> aa = new ArrayList<>();
      for(String other : associates) {
        if(!associate.equals(other))
          aa.add(other);
      }
      String[] as = new String[aa.size()];
      wordExpansions.putIfAbsent(associate, aa.toArray(as));
    }
  }//()

  public static String[] expand(String word) {
    if(wordExpansions == null) {
      wordExpansions = new HashMap<>();
      createAssociations();
    }
    return wordExpansions.getOrDefault(word, null);
  }//expand()

  private static void createAssociations() {
    new WordExpansion("method", "function");
    new WordExpansion("advantage", "benefit", "useful");
    new WordExpansion("slice", "subarray");
    new WordExpansion("stack", "queue", "tree", "set", "list", "graph", "adt");
  }//createAssociations()

}//class WordExpansion
